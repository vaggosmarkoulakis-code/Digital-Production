"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useMotionValueEvent, useReducedMotion, useScroll, useSpring, useTransform } from "framer-motion";
import Lenis from "lenis";
import greece from "@svg-maps/greece";
import type { LucideIcon } from "lucide-react";
import {
  ArrowDown, ArrowUpRight, Atom, Boxes, Braces, Camera, CheckCircle2,
  Cloud, Code2, Database, Flame, Globe2, Hexagon,
  Languages, Mail, MapPin, Menu, MessageCircle, MonitorSmartphone, MousePointer2,
  PenTool, Phone, Search, Send, Server, ShieldCheck, ShoppingBag, Sparkles, Triangle, Wind, X,
  Zap,
} from "lucide-react";

type GreeceLocation = {
  id: string;
  path: string;
};

const greeceLocations = greece.locations as GreeceLocation[];

const profile = {
  name: "Βαγγέλης Μαρκουλάκης",
  email: "markoulakisevan@gmail.com",
  phone: "+30 695 538 2035",
  location: "Κρήτη",
  instagram: "https://instagram.com/vagg_mrk",
  whatsapp: "https://wa.me/306955382035",
  linkedin: "#",
  github: "#",
  cv: "#",
};

const pricing = [
  { name: "Starter", price: "290€", note: "Για μια δυνατή πρώτη παρουσία", features: ["Έως 4 σελίδες", "Responsive design", "Φόρμα επικοινωνίας", "Google Maps & Social", "Βασικό SEO", "Παράδοση σε 5–7 ημέρες"] },
  { name: "Business", price: "490€", note: "Η πιο ολοκληρωμένη επιλογή", popular: true, features: ["Έως 8 σελίδες", "Premium σχεδιασμός", "Animations & Gallery", "Google Reviews & Instagram", "Βελτιστοποίηση ταχύτητας", "15 ημέρες υποστήριξη"] },
  { name: "Premium", price: "από 890€", note: "Για σύνθετες ψηφιακές ανάγκες", features: ["Custom σχεδιασμός", "Online κρατήσεις", "Dashboard", "Πολυγλωσσικό περιεχόμενο", "Premium animations", "1 μήνας υποστήριξη"] },
];

const pricingEnglish: Record<string,{note:string;features:string[]}> = {
  Starter:{note:"For a strong first online presence",features:["Up to 4 pages","Responsive design","Contact form","Google Maps & Social","Basic SEO","Delivery in 5–7 days"]},
  Business:{note:"The most complete choice",features:["Up to 8 pages","Premium design","Animations & Gallery","Google Reviews & Instagram","Speed optimization","15 days of support"]},
  Premium:{note:"For advanced digital needs",features:["Custom design","Online bookings","Dashboard","Multilingual content","Premium animations","1 month of support"]},
};

const work = [
  { title: "SOMA", category: "Hospitality Experience · 2026", desc: "Ψηφιακή ταυτότητα και εμπειρία για ένα σύγχρονο cocktail bar.", className: "project-soma" },
];

const tech = [
  {name:"NEXT.JS",icon:Boxes},
  {name:"REACT",icon:Atom},
  {name:"TYPESCRIPT",icon:Braces},
  {name:"TAILWIND",icon:Wind},
  {name:"FIREBASE",icon:Flame},
  {name:"NODE.JS",icon:Hexagon},
  {name:"VERCEL",icon:Triangle},
  {name:"FIGMA",icon:PenTool},
];

const serviceScenes: Array<{
  key: string;
  eyebrowEl: string;
  eyebrowEn: string;
  titleEl: string;
  titleEn: string;
  textEl: string;
  textEn: string;
  itemsEl: string[];
  itemsEn: string[];
  icon: LucideIcon;
}> = [
  {
    key: "presence",
    eyebrowEl: "ΨΗΦΙΑΚΗ ΠΑΡΟΥΣΙΑ",
    eyebrowEn: "DIGITAL PRESENCE",
    titleEl: "Η πρώτη εντύπωση που δεν ξεχνιέται.",
    titleEn: "A first impression that stays.",
    textEl: "Custom websites και landing pages με ισχυρή ταυτότητα, καθαρό μήνυμα και ταχύτητα σε κάθε συσκευή.",
    textEn: "Custom websites and landing pages with a distinct identity, clear messaging and speed on every device.",
    itemsEl: ["Επαγγελματικά websites", "Landing pages", "Website redesign"],
    itemsEn: ["Professional websites", "Landing pages", "Website redesign"],
    icon: Globe2,
  },
  {
    key: "commerce",
    eyebrowEl: "ΠΩΛΗΣΕΙΣ & ΚΡΑΤΗΣΕΙΣ",
    eyebrowEn: "COMMERCE & BOOKINGS",
    titleEl: "Από το ενδιαφέρον, στην ενέργεια.",
    titleEn: "From interest to action.",
    textEl: "E-shop, online παραγγελίες και κρατήσεις σχεδιασμένες για λιγότερα βήματα και περισσότερες ολοκληρωμένες ενέργειες.",
    textEn: "E-commerce, online ordering and booking flows designed for fewer steps and more completed actions.",
    itemsEl: ["E-shop", "Online παραγγελίες", "Συστήματα κρατήσεων"],
    itemsEn: ["E-commerce", "Online ordering", "Booking systems"],
    icon: ShoppingBag,
  },
  {
    key: "products",
    eyebrowEl: "ΨΗΦΙΑΚΑ ΠΡΟΪΟΝΤΑ",
    eyebrowEn: "DIGITAL PRODUCTS",
    titleEl: "Εργαλεία που δουλεύουν μαζί σας.",
    titleEn: "Tools that work with you.",
    textEl: "Mobile εφαρμογές, custom dashboards και αυτοματισμοί που λύνουν πραγματικές καθημερινές ανάγκες μιας επιχείρησης.",
    textEn: "Mobile applications, custom dashboards and automations built around real everyday business needs.",
    itemsEl: ["Mobile εφαρμογές", "Custom dashboards", "Αυτοματισμοί επιχειρήσεων"],
    itemsEn: ["Mobile applications", "Custom dashboards", "Business automation"],
    icon: MonitorSmartphone,
  },
  {
    key: "growth",
    eyebrowEl: "ΑΝΑΠΤΥΞΗ & ΦΡΟΝΤΙΔΑ",
    eyebrowEn: "GROWTH & CARE",
    titleEl: "Η παράδοση είναι μόνο η αρχή.",
    titleEn: "Launch is only the beginning.",
    textEl: "Local SEO, Google Business, hosting και συνεχιζόμενη υποστήριξη για μια παρουσία που εξελίσσεται με την επιχείρηση.",
    textEn: "Local SEO, Google Business, hosting and ongoing support for a presence that evolves with the business.",
    itemsEl: ["Google Business & SEO", "Hosting", "Τεχνική υποστήριξη"],
    itemsEn: ["Google Business & SEO", "Hosting", "Technical support"],
    icon: Zap,
  },
];

type RevealVariant = "up" | "right" | "left" | "zoom";

function Reveal({ children, className = "" }: { children: React.ReactNode; className?: string; delay?: number; variant?: RevealVariant }) {
  return <div className={className}>{children}</div>;
}

function MarkLogo({className=""}:{className?:string}) {
  return <span className={`mark-logo ${className}`} aria-hidden="true">
    <svg viewBox="0 0 64 64" fill="none">
      <defs><linearGradient id="markGradient" x1="8" y1="8" x2="57" y2="55" gradientUnits="userSpaceOnUse"><stop stopColor="#fff"/><stop offset=".5" stopColor="#72a7ff"/><stop offset="1" stopColor="#2563eb"/></linearGradient></defs>
      <path d="M8 48 21.5 13 32 35 43.5 8 56 48" stroke="url(#markGradient)" strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M17 48 31.5 18 47 48" stroke="url(#markGradient)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" opacity=".72"/>
      <path d="M8 55h48" stroke="url(#markGradient)" strokeWidth="2" strokeLinecap="round" opacity=".42"/>
    </svg>
  </span>;
}

function SectionLabel({ children, dark = false }: { children: React.ReactNode; dark?: boolean }) {
  return <div className={`section-label ${dark ? "label-dark" : ""}`}><span /><p>{children}</p></div>;
}

function MagneticLink({href,children,className=""}:{href:string;children:React.ReactNode;className?:string}){
  const [offset,setOffset]=useState({x:0,y:0});
  return <motion.a href={href} className={className} animate={{x:offset.x,y:offset.y}} transition={{type:"spring",stiffness:260,damping:18}} onMouseMove={(e)=>{const r=e.currentTarget.getBoundingClientRect();setOffset({x:(e.clientX-r.left-r.width/2)*.14,y:(e.clientY-r.top-r.height/2)*.18})}} onMouseLeave={()=>setOffset({x:0,y:0})}>{children}</motion.a>
}

function ServiceJourney({en}:{en:boolean}) {
  const ref=useRef<HTMLElement>(null);
  const [active,setActive]=useState(0);
  const reduced=useReducedMotion();
  const {scrollYProgress}=useScroll({target:ref,offset:["start start","end end"]});
  const progress=useSpring(scrollYProgress,{stiffness:120,damping:28,mass:.35});
  useMotionValueEvent(scrollYProgress,"change",(value)=>{
    const next=Math.min(serviceScenes.length-1,Math.max(0,Math.floor(value*serviceScenes.length)));
    setActive(next);
  });
  const scene=serviceScenes[active];
  const SceneIcon=scene.icon;
  const jumpTo=(index:number)=>{
    if(!ref.current)return;
    const travel=ref.current.offsetHeight-window.innerHeight;
    window.scrollTo({top:ref.current.offsetTop+(travel*index)/(serviceScenes.length-1),behavior:"smooth"});
  };
  return <section className={`services service-journey theme-${scene.key}`} id="services" ref={ref}>
    <div className="service-sticky">
      <motion.div className="service-theme-wash" key={scene.key} initial={reduced?false:{opacity:0}} animate={{opacity:1}} transition={{duration:.7}}/>
      <div className="service-journey-head">
        <SectionLabel dark>{en?"SCROLL THROUGH THE STUDIO":"ΠΕΡΙΗΓΗΘΕΙΤΕ ΣΤΟ STUDIO"}</SectionLabel>
        <p>{en?"Keep scrolling — the scene stays with you.":"Συνεχίστε την κύλιση — η σκηνή μένει μαζί σας."}</p>
      </div>
      <div className="service-story">
        <AnimatePresence mode="wait">
          <motion.article key={scene.key} className="service-story-copy" initial={reduced?false:{opacity:0,x:90}} animate={{opacity:1,x:0}} exit={reduced?undefined:{opacity:0,x:-45}} transition={{duration:.58,ease:[.16,1,.3,1]}}>
            <span>{en?scene.eyebrowEn:scene.eyebrowEl}</span>
            <h2>{en?scene.titleEn:scene.titleEl}</h2>
            <p>{en?scene.textEn:scene.textEl}</p>
            <div className="service-inline-list">{(en?scene.itemsEn:scene.itemsEl).map(item=><small key={item}><CheckCircle2/>{item}</small>)}</div>
          </motion.article>
        </AnimatePresence>
        <AnimatePresence mode="wait">
          <motion.div key={scene.key} className="service-story-art" initial={reduced?false:{opacity:0,scale:.82,rotate:-3}} animate={{opacity:1,scale:1,rotate:0}} exit={reduced?undefined:{opacity:0,scale:1.08,rotate:2}} transition={{duration:.7,ease:[.16,1,.3,1]}}>
            <svg className="service-flow-line" viewBox="0 0 620 420" preserveAspectRatio="none" aria-hidden="true"><path d="M-20 330C130 350 120 70 285 116s156 252 360 102"/><path d="M-20 365C155 388 148 112 312 150s142 205 335 118" opacity=".38"/></svg>
            <div className="service-glyph"><SceneIcon/></div>
            <strong>{en?scene.eyebrowEn:scene.eyebrowEl}</strong>
            <span>MARKOULAKIS<br/>DIGITAL STUDIO</span>
          </motion.div>
        </AnimatePresence>
      </div>
      <div className="service-chapters" role="tablist" aria-label={en?"Service chapters":"Κατηγορίες υπηρεσιών"}>
        {serviceScenes.map((item,index)=><button key={item.key} role="tab" aria-selected={active===index} className={active===index?"active":""} onClick={()=>jumpTo(index)}><i/><span>{en?item.eyebrowEn:item.eyebrowEl}</span></button>)}
      </div>
      <div className="service-scroll-progress" aria-hidden="true"><motion.i style={{scaleX:progress}}/></div>
    </div>
  </section>;
}

function JourneyIntro({onComplete,en}:{onComplete:()=>void;en:boolean}){
  const reduced=useReducedMotion();
  const creteId="crete";
  useEffect(()=>{const timer=window.setTimeout(onComplete,reduced?650:4600);return()=>window.clearTimeout(timer)},[onComplete,reduced]);
  return <motion.div className="journey-intro" role="dialog" aria-label={en?"Journey from Earth to Crete":"Ταξίδι από τη Γη προς την Κρήτη"} initial={{opacity:1}} exit={{opacity:0,scale:1.015}} transition={{duration:reduced?.2:.72,ease:[.22,1,.36,1]}}>
    <div className="journey-stars" aria-hidden="true">{Array.from({length:20},(_,i)=><i key={i} style={{left:`${(i*47)%97}%`,top:`${(i*67)%91}%`}}/>)}</div>
    <motion.div className="earth-stage" aria-hidden="true" initial={reduced?{opacity:0}:{opacity:0,scale:.82,x:"0%"}} animate={reduced?{opacity:0}:{opacity:[0,1,1,.68,0],scale:[.82,1,1.05,1.68,3.25],x:["0%","0%","-1%","-2.5%","-6%"]}} transition={{duration:3.5,times:[0,.16,.5,.76,1],ease:[.22,1,.36,1]}}>
      <div className="earth-globe">
        <motion.div className="earth-surface" initial={{x:"2%"}} animate={reduced?{x:"2%"}:{x:"-17%"}} transition={{duration:4.1,ease:"linear"}}>
          <img src="/world-map.webp" alt=""/>
          <img src="/world-map.webp" alt=""/>
        </motion.div>
        <div className="earth-atmosphere"/>
        <div className="earth-shadow"/>
      </div>
    </motion.div>
    <motion.div className="journey-haze" aria-hidden="true" initial={{opacity:0}} animate={reduced?{opacity:0}:{opacity:[0,0,.24,0]}} transition={{delay:1.55,duration:1.5,times:[0,.28,.62,1],ease:"easeInOut"}}/>
    <motion.div className="greece-stage" aria-hidden="true" initial={{opacity:reduced?1:0,scale:reduced?1:.64,y:reduced?0:12}} animate={{opacity:1,scale:1.02,y:0}} transition={{delay:reduced?0:1.65,duration:1.55,ease:[.16,1,.3,1]}}>
      <svg viewBox="0 0 919 793">
        {greeceLocations.map((location)=><path key={location.id} d={location.path} className={location.id===creteId?"intro-crete":"intro-region"}/>)}
        <g className="intro-pin"><path d="M430 736l3.7 8.3 8.3 3.7-8.3 3.7-3.7 8.3-3.7-8.3-8.3-3.7 8.3-3.7z"/><circle cx="430" cy="748" r="2.5"/></g>
      </svg>
    </motion.div>
    <div className="journey-coordinates">35.067° N&nbsp;&nbsp;24.767° E</div>
    <motion.div className="journey-location" initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{delay:reduced?0:2.45,duration:.8,ease:[.16,1,.3,1]}}><span>{en?"ARRIVING IN":"ΠΡΟΟΡΙΣΜΟΣ"}</span><strong>{en?"CRETE, GREECE":"ΚΡΗΤΗ, ΕΛΛΑΔΑ"}</strong></motion.div>
    <motion.p className="journey-message" initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{delay:reduced?0:2.75,duration:.85,ease:[.16,1,.3,1]}}>{en?"Technology with a local point of view.":"Τεχνολογία με αφετηρία τον τόπο μου."}</motion.p>
    <button className="journey-skip" onClick={onComplete}>{en?"SKIP":"ΠΑΡΑΛΕΙΨΗ"} <ArrowUpRight/></button>
  </motion.div>
}

function CreteMap({en}:{en:boolean}){
  const cretePath=greeceLocations.find((location)=>location.id==="crete")?.path ?? "";
  return <div className="crete-map-card">
    <div className="map-heading"><MapPin/><span>{en?"SOUTH CRETE · GREECE":"ΝΟΤΙΑ ΚΡΗΤΗ · ΕΛΛΑΔΑ"}</span></div>
    <svg className="crete-map" viewBox="270 680 370 115" role="img" aria-label={en?"Accurate map of Crete with Tympaki highlighted":"Ακριβής χάρτης της Κρήτης με σημειωμένο το Τυμπάκι"}>
      <defs><linearGradient id="creteGradient" x1="270" y1="700" x2="630" y2="770" gradientUnits="userSpaceOnUse"><stop stopColor="#164fbd"/><stop offset="1" stopColor="#3b82f6"/></linearGradient><filter id="mapShadow"><feDropShadow dx="0" dy="7" stdDeviation="6" floodColor="#173f91" floodOpacity=".22"/></filter></defs>
      <path d={cretePath} fill="url(#creteGradient)" filter="url(#mapShadow)"/>
      <motion.g className="tympaki-marker" tabIndex={0} role="button" aria-label={en?"Tympaki, Heraklion":"Τυμπάκι, Ηράκλειο"} whileHover={{scale:1.18,rotate:8}} whileFocus={{scale:1.18,rotate:8}} transition={{type:"spring",stiffness:280,damping:18}} style={{transformOrigin:"430px 748px"}}>
        <path d="M430 735l4 9 9 4-9 4-4 9-4-9-9-4 9-4z" fill="#fff" stroke="#174fb8" strokeWidth="1.5"/>
        <circle cx="430" cy="748" r="2.8" fill="#2563eb"/>
      </motion.g>
    </svg>
    <div className="map-label"><span/><div><b>{en?"TYMPAKI":"ΤΥΜΠΑΚΙ"}</b><small>{en?"My starting point in Crete":"Το σημείο εκκίνησής μου στην Κρήτη"}</small></div></div>
    <h3>{en?<>Investing in Crete’s technology.<br/>Building <em>our local future.</em></>:<>Επενδύω στην τεχνολογία της Κρήτης.<br/>Χτίζω <em>το μέλλον του τόπου μου.</em></>}</h3>
  </div>
}

function DeviceIllustration() {
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, .2], [0, 90]);
  const scale = useTransform(scrollYProgress, [0, .2], [1, 1.085]);
  const opacity = useTransform(scrollYProgress, [0, .2], [1, .58]);
  return (
    <motion.div className="device-scene" style={{ y,scale,opacity }} aria-label="Digital products illustration">
      <div className="float-chip chip-cloud"><Cloud size={22}/><span>Cloud</span></div>
      <div className="float-chip chip-code"><Code2 size={22}/><span>Clean code</span></div>
      <div className="float-icon icon-db"><Database size={21}/></div>
      <div className="float-icon icon-server"><Server size={21}/></div>
      <div className="laptop">
        <div className="laptop-screen">
          <div className="screen-top"><i/><i/><i/><span>markoulakis.dev</span></div>
          <div className="screen-grid">
            <div className="screen-side"><MarkLogo className="mark-logo-screen"/><i/><i/><i/><i/></div>
            <div className="screen-main">
              <span className="code-tag">DIGITAL STUDIO</span>
              <h3>We build<br/><em>what’s next.</em></h3>
              <div className="screen-bars"><i/><i/><i/></div>
              <div className="screen-stats"><span>98<small>PERFORMANCE</small></span><span>100<small>ACCESSIBILITY</small></span></div>
            </div>
          </div>
        </div>
        <div className="laptop-base" />
      </div>
      <div className="phone-mock">
        <div className="phone-notch"/><div className="phone-logo"><MarkLogo className="mark-logo-phone"/></div><div className="phone-copy">IDEAS<br/><span>IN MOTION</span></div><div className="phone-pill">EXPLORE <ArrowUpRight size={10}/></div>
      </div>
      <MousePointer2 className="cursor-art" size={30}/>
    </motion.div>
  );
}

function SomaProject({project,en}:{project:(typeof work)[number];en:boolean}) {
  const ref=useRef<HTMLDivElement>(null);
  const reduced=useReducedMotion();
  const {scrollYProgress}=useScroll({target:ref,offset:["start 92%","center 48%"]});
  const scale=useTransform(scrollYProgress,[0,1],[reduced?1:.84,1]);
  const y=useTransform(scrollYProgress,[0,1],[reduced?0:85,0]);
  const opacity=useTransform(scrollYProgress,[0,.55],[reduced?1:.25,1]);
  return <motion.div ref={ref} className="project-zoom-stage" style={{scale,y,opacity}}>
    <article className={`project ${project.className}`}>
      <div className="project-meta"><span>SELECTED WORK</span><div><p>{project.category}</p><h3>{project.title}</h3><small>{project.desc}</small></div></div>
      <div className="project-visual">
        <div className="soma-browser">
          <div className="soma-browser-bar"><div><i/><i/><i/></div><span>soma-tympaki.gr</span></div>
          <div className="soma-desktop-screen"><img src="/soma-showcase.webp" alt={en?"SOMA cocktail bar website on desktop":"Η ιστοσελίδα του SOMA σε υπολογιστή"}/></div>
          <div className="soma-laptop-base"><span/></div>
        </div>
        <div className="soma-phone" aria-label={en?"SOMA website mobile preview":"Η ιστοσελίδα του SOMA σε κινητό"}>
          <i className="phone-side phone-side-a"/><i className="phone-side phone-side-b"/>
          <div className="soma-phone-screen"><img src="/soma-showcase.webp" alt={en?"SOMA cocktail bar website on mobile":"Η ιστοσελίδα του SOMA σε κινητό"}/><span className="soma-island"/><span className="soma-home"/></div>
        </div>
        <span className="project-open" aria-hidden="true"><ArrowUpRight/></span>
      </div>
    </article>
  </motion.div>;
}

export default function Home() {
  const [menu, setMenu] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [lang, setLang] = useState<"el"|"en">("el");
  const [selectedPlan,setSelectedPlan]=useState("Business");
  const [submitted,setSubmitted]=useState(false);
  const [compactNav,setCompactNav]=useState(false);
  const {scrollYProgress}=useScroll();
  const heroTextY=useTransform(scrollYProgress,[0,.16],[0,-65]);
  const heroTextScale=useTransform(scrollYProgress,[0,.16],[1,.94]);
  const en=lang==="en";
  const finishIntro=useCallback(()=>setLoaded(true),[]);
  useEffect(()=>{document.body.style.overflow=loaded?"":"hidden";return()=>{document.body.style.overflow=""}},[loaded]);
  useEffect(()=>{
    if(window.matchMedia("(prefers-reduced-motion: reduce)").matches)return;
    const lenis=new Lenis({lerp:.105,smoothWheel:true,wheelMultiplier:1,touchMultiplier:1.08});
    let frame=0;const raf=(time:number)=>{lenis.raf(time);frame=requestAnimationFrame(raf)};frame=requestAnimationFrame(raf);
    return()=>{cancelAnimationFrame(frame);lenis.destroy()};
  },[]);
  useEffect(()=>{const update=()=>setCompactNav(window.scrollY>Math.max(280,window.innerHeight*.55));update();window.addEventListener("scroll",update,{passive:true});return()=>window.removeEventListener("scroll",update)},[]);
  useEffect(()=>{document.documentElement.lang=lang},[lang]);
  const submitContact=(e:React.FormEvent<HTMLFormElement>)=>{e.preventDefault();const data=new FormData(e.currentTarget);setSubmitted(true);const subject=encodeURIComponent(`Νέο αίτημα: ${data.get("project")}`);const body=encodeURIComponent(`Όνομα: ${data.get("name")}\nΤηλέφωνο: ${data.get("phone")}\nProject: ${data.get("project")}\nΜήνυμα: ${data.get("message")}`);setTimeout(()=>{window.location.href=`mailto:${profile.email}?subject=${subject}&body=${body}`},550)};

  return (
    <main className="journey-page">
      <AnimatePresence>{!loaded&&<JourneyIntro onComplete={finishIntro} en={en}/>}</AnimatePresence>
      <div className="page-atmosphere" aria-hidden="true"/>
      <header className={`nav-wrap ${compactNav?"nav-compact":""}`}>
        <a href="#top" className="brand" aria-label="Markoulakis Digital Studio — αρχική"><MarkLogo/><div>MARKOULAKIS<small>DIGITAL STUDIO</small></div></a>
        <nav className={menu ? "nav-open" : ""}>
          <a href="#about" onClick={()=>setMenu(false)}>Studio</a><a href="#services" onClick={()=>setMenu(false)}>{en?"Services":"Υπηρεσίες"}</a><a href="#pricing" onClick={()=>setMenu(false)}>{en?"Pricing":"Πακέτα"}</a><a href="#work" onClick={()=>setMenu(false)}>{en?"Work":"Έργα"}</a><a href="#process" onClick={()=>setMenu(false)}>{en?"Process":"Διαδικασία"}</a>
          <button className="lang-switch" onClick={()=>setLang(en?"el":"en")} aria-label="Change language"><Languages size={14}/>{en?"EL":"EN"}</button>
          <a href="#contact" className="nav-cta" onClick={()=>setMenu(false)}>{en?"Let’s talk":"Ας μιλήσουμε"} <ArrowUpRight size={16}/></a>
        </nav>
        <button className="menu-btn" onClick={()=>setMenu(!menu)} aria-label="Μενού">{menu?<X/>:<Menu/>}</button>
      </header>

      <section className="hero" id="top">
        <div className="hero-noise"/><div className="hero-grid"/><div className="hero-glow hero-glow-a"/><div className="hero-glow hero-glow-b"/>
        <div className="hero-content">
          <motion.div className="hero-copy" style={{y:heroTextY,scale:heroTextScale}} initial={{opacity:0}} animate={loaded?{opacity:1}:{}} transition={{duration:.8}}>
            <div className="availability"><span/> {en?"Your new website online within 2 weeks":"Νέα ιστοσελίδα online σε έως 2 εβδομάδες"}</div>
            <p className="eyebrow">ΒΑΓΓΕΛΗΣ ΜΑΡΚΟΥΛΑΚΗΣ · CRETE</p>
            <h1 className="kinetic-title"><motion.span initial={{y:70,rotate:2}} animate={loaded?{y:0,rotate:0}:{}} transition={{duration:.9,ease:[.16,1,.3,1]}}>Digital experiences</motion.span><br/><motion.span initial={{y:70,rotate:-2}} animate={loaded?{y:0,rotate:0}:{}} transition={{duration:.9,delay:.1,ease:[.16,1,.3,1]}}>built to <em>stand out.</em></motion.span></h1>
            <p className="hero-lead">{en?"I design modern websites and applications that help ambitious businesses stand out.":"Σχεδιάζω σύγχρονες ιστοσελίδες και εφαρμογές που βοηθούν φιλόδοξες επιχειρήσεις να ξεχωρίζουν."}</p>
            <div className="hero-actions">
              <MagneticLink href="#services" className="btn btn-primary">{en?"Explore services":"Δείτε τις υπηρεσίες"} <ArrowDown size={17}/></MagneticLink>
              <MagneticLink href="#contact" className="btn btn-ghost">{en?"Start a project":"Ξεκινήστε ένα project"} <ArrowUpRight size={17}/></MagneticLink>
            </div>
            <div className="trust-row"><div><ShieldCheck/>{en?"Strategy":"Στρατηγική"}</div><div><Zap/>{en?"Speed":"Ταχύτητα"}</div><div><Sparkles/>{en?"Experience":"Εμπειρία"}</div></div>
          </motion.div>
          <motion.div initial={{opacity:0,scale:.92}} animate={loaded?{opacity:1,scale:1}:{}} transition={{duration:1,delay:.15}}><DeviceIllustration/></motion.div>
        </div>
        <div className="scroll-note"><span>MOVE TO EXPLORE</span><i/></div>
      </section>

      <section className="manifesto">
        <Reveal variant="left"><SectionLabel>{en?"THE STUDIO":"ΤΟ STUDIO"}</SectionLabel></Reveal>
        <Reveal variant="zoom"><h2>{en?"We don’t simply build websites.":"Δεν κατασκευάζουμε απλώς ιστοσελίδες."}<br/><span>{en?"We create digital advantage.":"Δημιουργούμε ψηφιακό πλεονέκτημα."}</span></h2></Reveal>
        <Reveal variant="right"><div className="manifesto-foot"><p>{en?"We combine strategy, design and technology to turn a strong idea into an experience people remember.":"Συνδυάζουμε στρατηγική, design και τεχνολογία για να μετατρέψουμε μια καλή ιδέα σε εμπειρία που θυμούνται οι άνθρωποι."}</p><a href="#about">{en?"DISCOVER OUR PHILOSOPHY":"ΑΝΑΚΑΛΥΨΤΕ ΤΗ ΦΙΛΟΣΟΦΙΑ ΜΑΣ"} <ArrowUpRight/></a></div></Reveal>
      </section>

      <section className="about" id="about">
        <div className="about-layout">
          <Reveal className="about-title" variant="left"><SectionLabel>{en?"ABOUT":"ΣΧΕΤΙΚΑ"}</SectionLabel><h2>{en?"Driven by technology.":"Με πάθος για την τεχνολογία."}<br/><span>{en?"Inspired by Crete.":"Με όραμα για την Κρήτη."}</span></h2></Reveal>
          <Reveal className="about-copy" variant="right"><p>{en?<>My name is <strong>Vangelis Markoulakis</strong> and I study Computer Science at the Athens University of Economics and Business. I design professional websites, mobile products and complete digital systems for businesses.</>:<>Ονομάζομαι <strong>Βαγγέλης Μαρκουλάκης</strong> και σπουδάζω Πληροφορική στην ΑΣΟΕΕ. Σχεδιάζω και αναπτύσσω επαγγελματικές ιστοσελίδες, εφαρμογές κινητών και ολοκληρωμένα ψηφιακά συστήματα για επιχειρήσεις.</>}</p><p>{en?"My goal is to invest in Crete’s technology ecosystem and give local businesses modern tools that save time, elevate their image and help them stand out.":"Στόχος μου είναι να επενδύσω στην τεχνολογία της Κρήτης και να βοηθήσω τις τοπικές επιχειρήσεις να αποκτήσουν σύγχρονα ψηφιακά εργαλεία που εξοικονομούν χρόνο, αναβαθμίζουν την εικόνα τους και τις κάνουν να ξεχωρίζουν."}</p></Reveal>
          <Reveal className="cv-card" variant="zoom">
            <div className="cv-top"><div className="cv-monogram"><MarkLogo/></div><div><span>PROFILE / 2026</span><h3>{profile.name}</h3><p>Software Engineer & Digital Designer</p></div><a href={`mailto:${profile.email}`} aria-label="Επικοινωνία"><ArrowUpRight/></a></div>
            <div className="cv-info"><div><span>{en?"EDUCATION":"ΣΠΟΥΔΕΣ"}</span><b>{en?"AUEB · Computer Science":"ΑΣΟΕΕ · Πληροφορική"}</b></div><div><span>{en?"BASE":"ΒΑΣΗ"}</span><b>{en?"Crete":"Κρήτη"}</b></div><div><span>{en?"MISSION":"ΑΠΟΣΤΟΛΗ"}</span><b>{en?"Digital solutions for business":"Ψηφιακές λύσεις για επιχειρήσεις"}</b></div></div>
            <div className="skills-title"><b>{en?"CORE SKILLS":"ΒΑΣΙΚΕΣ ΔΕΞΙΟΤΗΤΕΣ"}</b><span>{en?"Always evolving":"Συνεχής εξέλιξη"}</span></div>
            <div className="skill-signals">{["Web Design & UI/UX","React / Next.js","TypeScript","Mobile Applications","Business Automation","Firebase & Cloud"].map(skill=><span key={skill}><CheckCircle2/>{skill}</span>)}</div>
          </Reveal>
          <Reveal className="map-column" variant="right"><CreteMap en={en}/></Reveal>
        </div>
      </section>

      <ServiceJourney en={en}/>

      <section className="pricing" id="pricing">
        <div className="pricing-head"><Reveal variant="left"><SectionLabel>{en?"WEBSITE PACKAGES":"ΠΑΚΕΤΑ ΙΣΤΟΣΕΛΙΔΩΝ"}</SectionLabel><h2>{en?"Start with confidence.":"Ξεκινήστε σωστά."}<br/><span>{en?"From €290.":"Από 290€."}</span></h2></Reveal><Reveal variant="right"><div className="delivery-promise"><ShieldCheck/><div><b>{en?"Delivery guarantee":"Εγγύηση παράδοσης"}</b><p>{en?"Your website online within 2 weeks for local businesses.":"Η ιστοσελίδα σας online μέσα σε 2 εβδομάδες για τοπικά καταστήματα."}</p></div></div></Reveal></div>
        <div className="plan-selector" role="tablist" aria-label="Choose a package">{pricing.map(plan=><button key={plan.name} className={selectedPlan===plan.name?"active":""} onClick={()=>setSelectedPlan(plan.name)}>{plan.name}</button>)}</div>
        <div className="pricing-grid">{pricing.map((plan,i)=>{const translated=en?pricingEnglish[plan.name]:{note:plan.note,features:plan.features};return <Reveal key={plan.name} delay={i*.06} variant="zoom"><article onMouseEnter={()=>setSelectedPlan(plan.name)} className={`price-card ${selectedPlan===plan.name?"price-popular":""}`}>{plan.popular&&<div className="popular-tag">{en?"MOST POPULAR":"ΠΙΟ ΔΗΜΟΦΙΛΕΣ"}</div>}<p className="plan-name">{plan.name}</p><h3>{en&&plan.price.startsWith("από")?"from €890":plan.price}</h3><small>{translated.note}</small><div className="price-line"/><ul>{translated.features.map(feature=><li key={feature}><ShieldCheck/>{feature}</li>)}</ul><a href={`mailto:${profile.email}?subject=${en?"Interested in":"Ενδιαφέρομαι για το πακέτο"} ${plan.name}`}>{en?"REQUEST A QUOTE":"ΖΗΤΗΣΤΕ ΠΡΟΣΦΟΡΑ"} <ArrowUpRight/></a></article></Reveal>})}</div>
        <Reveal variant="right"><div className="pricing-note"><p><b>{en?"Mobile apps, automations and custom systems:":"Mobile εφαρμογές, αυτοματισμοί και ειδικά συστήματα:"}</b> {en?"priced after consultation.":"κατόπιν επικοινωνίας."}</p><span>{en?"Domain and hosting are quoted separately, so you always know exactly what you pay for.":"Domain και hosting υπολογίζονται ξεχωριστά, ώστε να γνωρίζετε πάντα ακριβώς τι πληρώνετε."}</span></div></Reveal>
      </section>

      <section className="work" id="work">
        <div className="work-head"><Reveal variant="left"><SectionLabel dark>SELECTED WORK</SectionLabel><h2>{en?"Projects designed":"Projects σχεδιασμένα"}<br/>{en?"to ":"για να "}<span>{en?"stand out.":"ξεχωρίζουν."}</span></h2></Reveal><Reveal variant="right"><p>{en?"Selected digital experiences with clear strategy, distinct identity and technology built to last.":"Επιλεγμένες ψηφιακές εμπειρίες με καθαρή στρατηγική, ιδιαίτερη ταυτότητα και τεχνολογία που αντέχει στον χρόνο."}</p></Reveal></div>
        <div className="projects">{work.map(project=><SomaProject key={project.title} project={project} en={en}/>)}</div>
      </section>

      <section className="facts">
        <Reveal className="facts-heading" variant="zoom"><SectionLabel>{en?"A FEW TRUE THINGS":"ΜΕΡΙΚΑ ΑΛΗΘΙΝΑ FACTS"}</SectionLabel><h2>{en?"The person behind":"Ο άνθρωπος πίσω από"}<br/><span>{en?"the digital studio.":"το digital studio."}</span></h2></Reveal>
        <div className="facts-flow">{[
          [MapPin,en?"Based in Crete":"Βάση στην Κρήτη",en?"The place I want to see evolve through technology.":"Ο τόπος που θέλω να δω να εξελίσσεται μέσα από την τεχνολογία."],
          [Braces,en?"Computer Science at AUEB":"Πληροφορική στην ΑΣΟΕΕ",en?"Knowledge that becomes hands-on work every day.":"Γνώση που μετατρέπεται καθημερινά σε πρακτική δημιουργία."],
          [PenTool,en?"Engineering meets design":"Μηχανική σκέψη και design",en?"I care equally about how a product works and how it feels.":"Με ενδιαφέρει εξίσου το πώς λειτουργεί ένα προϊόν και το πώς το αισθάνεται ο χρήστης."],
          [Globe2,en?"Local vision, wider standards":"Τοπικό όραμα, διεθνή standards",en?"Digital work from Crete, designed to compete anywhere.":"Ψηφιακή δουλειά από την Κρήτη, σχεδιασμένη για να στέκεται παντού."],
          [Sparkles,en?"Every project has a purpose":"Κάθε project έχει λόγο ύπαρξης",en?"No templates for the sake of speed — every decision serves the business.":"Όχι έτοιμες λύσεις για ευκολία — κάθε απόφαση υπηρετεί την επιχείρηση."],
        ].map(([Icon,t,d],i)=><Reveal key={String(t)} className={`fact-item fact-shift-${i%3}`} delay={i*.045} variant={i%2===0?"right":"left"}><Icon/><div><h3>{String(t)}</h3><p>{String(d)}</p></div></Reveal>)}</div>
      </section>

      <section className="process" id="process">
        <Reveal variant="zoom"><SectionLabel dark>HOW WE WORK</SectionLabel><h2>{en?"From an idea":"Από την ιδέα"}<br/><span>{en?"to reality.":"στην πραγματικότητα."}</span></h2></Reveal>
        <div className="process-list">{(en?["Discovery call","Needs analysis","Design","Development","Testing","Launch"]:["Δωρεάν συζήτηση","Ανάλυση αναγκών","Σχεδιασμός","Ανάπτυξη","Έλεγχος","Παράδοση"]).map((x,i)=>{const ProcessIcon=[MessageCircle,Search,PenTool,Code2,ShieldCheck,Zap][i];return <Reveal key={x} delay={i*.035} variant="right"><div className="process-step"><span className="process-icon"><ProcessIcon/></span><h3>{x}</h3><div>{en?["We listen to your vision and define the goal.","We turn your needs into a clear plan.","We design every point of the experience.","We bring the design to life with modern code.","We test everything across every device.","We launch, train and support you."][i]:["Ακούμε το όραμά σας και ορίζουμε τον στόχο.","Μετατρέπουμε τις ανάγκες σε καθαρό πλάνο.","Σχεδιάζουμε κάθε σημείο της εμπειρίας.","Δίνουμε ζωή στο design με σύγχρονο κώδικα.","Δοκιμάζουμε τα πάντα σε κάθε συσκευή.","Παραδίδουμε, εκπαιδεύουμε και υποστηρίζουμε."][i]}</div><ArrowUpRight/></div></Reveal>})}</div>
      </section>

      <section className="tech"><p>THE TOOLS BEHIND THE EXPERIENCE</p><div className="marquee"><div>{[...tech,...tech].map((tool,i)=>{const ToolIcon=tool.icon;return <span key={`${tool.name}-${i}`}><i className="tech-icon"><ToolIcon/></i>{tool.name}</span>})}</div></div></section>

      <section className="contact" id="contact">
        <div className="contact-glow"/><div className="contact-layout"><Reveal variant="left"><p className="eyebrow">{en?"HAVE AN IDEA?":"ΕΧΕΤΕ ΜΙΑ ΙΔΕΑ;"}</p><h2>{en?"Let’s create something":"Ας δημιουργήσουμε κάτι"}<br/><span>{en?"worth remembering.":"που αξίζει να ξεχωρίζει."}</span></h2><p className="contact-lead">{en?"Tell me a little about your project and I’ll get back to you for a free initial conversation.":"Πείτε μου λίγα πράγματα για το project σας και θα επικοινωνήσω μαζί σας για μια δωρεάν πρώτη συζήτηση."}</p></Reveal>
        <Reveal variant="right"><form className={`contact-form ${submitted?"form-sent":""}`} onSubmit={submitContact}>{submitted?<div className="form-success"><CheckCircle2/><h3>{en?"Your request is ready":"Το αίτημά σας είναι έτοιμο"}</h3><p>{en?"Your email application is opening so you can send it securely.":"Ανοίγει η εφαρμογή email για να το στείλετε με ασφάλεια."}</p><button type="button" onClick={()=>setSubmitted(false)}>{en?"NEW MESSAGE":"ΝΕΟ ΜΗΝΥΜΑ"}</button></div>:<><label>{en?"NAME":"ΟΝΟΜΑ"}<input name="name" required placeholder={en?"Your name":"Το όνομά σας"}/></label><label>{en?"PHONE":"ΤΗΛΕΦΩΝΟ"}<input name="phone" type="tel" required placeholder="69XXXXXXXX"/></label><label>{en?"PROJECT TYPE":"ΤΥΠΟΣ PROJECT"}<select name="project" defaultValue="Website"><option>Website</option><option>E-shop</option><option>Mobile App</option><option>Automation</option><option>Redesign</option></select></label><label>{en?"A FEW WORDS":"ΛΙΓΑ ΛΟΓΙΑ"}<textarea name="message" required placeholder={en?"What would you like us to build?":"Τι θα θέλατε να δημιουργήσουμε;"}/></label><button type="submit"><span>{en?"PREPARE REQUEST":"ΕΤΟΙΜΑΣΙΑ ΑΙΤΗΜΑΤΟΣ"}</span><Send/></button></>}</form></Reveal></div>
        <div className="contact-details"><a href={`mailto:${profile.email}`}><Mail/>{profile.email}</a><a href={`tel:${profile.phone}`}><Phone/>{profile.phone}</a><a href={profile.whatsapp} target="_blank" rel="noreferrer"><MessageCircle/>WhatsApp / Viber</a><span><Globe2/>{profile.location}</span></div>
      </section>

      <footer><div className="footer-brand"><MarkLogo/><p>MARKOULAKIS<br/><span>DIGITAL STUDIO</span></p></div><p className="footer-slogan">Χτίζοντας το μέλλον της τοπικής επιχειρηματικότητας<br/>μέσα από την τεχνολογία.</p><div className="socials"><a href={profile.instagram} target="_blank" rel="noreferrer" aria-label="Instagram"><Camera/></a><a href={profile.whatsapp} target="_blank" rel="noreferrer" aria-label="WhatsApp"><MessageCircle/></a></div><div className="footer-bottom"><span>© 2026 MARKOULAKIS DIGITAL STUDIO</span><a href="#top">BACK TO TOP <ArrowDown/></a></div></footer>
    </main>
  );
}
