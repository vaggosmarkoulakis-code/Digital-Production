import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin", "greek"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Markoulakis Digital Studio | Ιστοσελίδες & Εφαρμογές στην Κρήτη",
  description: "Premium ιστοσελίδες, εφαρμογές και ψηφιακές λύσεις για φιλόδοξες επιχειρήσεις στην Κρήτη και σε όλη την Ελλάδα.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="el">
      <body className={`${inter.variable} antialiased`}>
        {children}
      </body>
    </html>
  );
}
